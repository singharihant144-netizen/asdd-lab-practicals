# WMC Viva Questions and Short Answers

Prepared from the three supplied WMC simulations. Explain the simplified models honestly and refer to your own output.

## WMC-01: Handover between base stations

### 01. What is handover in a mobile network?

Handover transfers an active mobile connection from one serving base station or cell to another as the user moves, helping maintain service continuity.

### 02. What does this simulation use as the mobile's position?

It creates 101 positions from 0 to 100 metres with NumPy linspace and treats position as the independent variable for the two signal-strength curves.

### 03. How are the two base-station signals modeled?

The script uses simple linear models: BS1 starts stronger and decreases with distance, while BS2 starts weaker and increases as the mobile approaches it. This is an illustrative model, not a measured propagation model.

### 04. How is the handover point represented?

A vertical dashed line and a marker are drawn at 50 metres, where the two modeled signal curves meet at approximately -75 dBm.

### 05. What does dBm measure?

dBm expresses power in decibels relative to one milliwatt. Received wireless powers are often negative dBm values; a value closer to zero represents more power.

### 06. Why should practical handover use more than a single signal crossing?

Real systems account for thresholds, hysteresis, time-to-trigger, interference, load, measurements, and control signaling. A crossing alone can cause rapid back-and-forth handovers.

### 07. What is a ping-pong handover?

It is a rapid sequence of handovers between cells, often caused by noisy or fluctuating measurements near a boundary. Hysteresis and time-to-trigger help reduce it.

### 08. What role does NumPy linspace play?

numpy.linspace(0, 100, 101) generates evenly spaced position samples including both endpoints, so the signal values can be plotted along the route.

### 09. What does the plot tell you when BS2 becomes stronger?

Under this simplified model, the mobile should transition its serving connection from BS1 to BS2 near the handover location so the stronger neighboring signal can serve it.

### 10. How could you improve this experiment?

Use a path-loss or fading model, add measurement noise and a configurable hysteresis threshold, simulate time, and compare signal-based handover with a time-to-trigger rule.

## WMC-02: Multipath channel effect

### 01. What is multipath propagation?

A transmitted radio signal can reach a receiver over several paths after reflection, diffraction, or scattering. The copies can arrive with different delays and amplitudes.

### 02. How does the script create the transmitted waveform?

It samples a 10 Hz sine wave over one second using NumPy linspace with 1,000 points.

### 03. What do path1, path2, and path3 represent?

Path1 is the original waveform, path2 is a delayed copy scaled to 0.6 amplitude, and path3 is another delayed copy scaled to 0.3 amplitude.

### 04. What does numpy.roll do in this script?

It shifts the sampled waveform by a fixed number of array positions. Here 50 and 100 samples model discrete delays; the operation wraps the end samples back to the beginning.

### 05. Why can multipath distort the received signal?

The receiver adds copies with different phase and delay. Depending on their alignment, they can reinforce or cancel parts of the signal, changing its amplitude and shape.

### 06. What does the received signal rx calculate?

rx is the point-by-point sum of path1, path2, and path3, representing the combined waveform at the receiver in this simple model.

### 07. What is a limitation of circular shifting with numpy.roll?

It wraps samples from the end of the waveform to its start, which is not a realistic finite-duration propagation delay. Padding with zeros or modeling a continuous sequence avoids this wrap-around artifact.

### 08. How are delay and amplitude represented?

Delay is represented by the number of shifted samples, while attenuation is represented by multiplying each delayed copy by a coefficient such as 0.6 or 0.3.

### 09. What is a channel impulse response?

It describes how a channel responds to an ideal impulse. In a discrete multipath model it can be represented by taps at path delays with amplitudes or complex gains.

### 10. How could you extend the multipath experiment?

Avoid circular wrap-around, add more paths with configurable delay and gain, use complex baseband signals, add noise, and compare equalized and unequalized reception.

## WMC-03: BPSK transmission and BER with AWGN

### 01. What is BPSK?

Binary Phase Shift Keying maps the two bit values to two carrier phases separated by 180 degrees. In the script's baseband representation the symbols are -1 and +1.

### 02. How are random bits generated?

NumPy draws 1,000 integers from 0 and 1. The expression 2*bits-1 maps zero to -1 and one to +1.

### 03. What does AWGN mean?

Additive White Gaussian Noise is a model of random noise added to a signal, with Gaussian amplitude distribution and approximately flat power spectral density over the modeled bandwidth.

### 04. How is SNR in decibels converted to a linear ratio?

The script uses 10 raised to SNR_dB divided by 10. Thus 5 dB becomes a linear power ratio of about 3.16.

### 05. Why is noise variance related to SNR?

For the chosen unit-energy BPSK symbols, the script sets variance to 1/(2*SNR), then draws zero-mean Gaussian noise with standard deviation equal to the square root of that variance.

### 06. How does the receiver decide each bit?

It uses a zero threshold: positive received samples are decoded as bit 1 and negative samples as bit 0. This is the maximum-likelihood decision rule for equally likely BPSK symbols in symmetric AWGN.

### 07. What is bit error rate?

BER is the number of incorrectly detected bits divided by the total number of transmitted bits. It estimates link reliability for the tested conditions.

### 08. Why can a measured BER vary between runs?

The bits and Gaussian noise are random, and the experiment uses only 1,000 bits. Fixing a random seed improves repeatability; transmitting more bits gives a more stable estimate, especially at low error rates.

### 09. What should happen to BER as SNR increases?

For coherent BPSK in AWGN, higher SNR generally lowers BER because noise is less likely to push a received symbol across the zero decision threshold.

### 10. What are limitations of this BPSK simulation?

It uses a short uncoded baseband sequence, a single SNR point, and no carrier, pulse shaping, synchronization errors, or fading. It is a useful demonstration rather than a complete radio-link model.
